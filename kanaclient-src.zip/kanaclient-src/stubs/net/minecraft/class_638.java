package net.minecraft;
public class class_638 { public class_2680 method_8320(class_2338 p){return null;} public boolean method_8393(int a,int b){return false;} public int method_31607(){return 0;} public int method_31605(){return 0;} }
