package net.minecraft;
public class class_238 { public class_238(class_2338 p){} }
