package net.minecraft;
public class class_332 { public class_4587 method_51448(){return null;} public int method_51421(){return 0;} public int method_51443(){return 0;} public void method_25300(class_327 f,String s,int x,int y,int c){} }
