package net.minecraft;
public enum class_1713 { field_7790, field_7791, field_7792, field_7793, field_7794, field_7795 }
