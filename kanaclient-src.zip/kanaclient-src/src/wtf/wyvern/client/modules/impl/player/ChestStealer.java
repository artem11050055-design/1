package wtf.wyvern.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_437;
import net.minecraft.class_476;
import wtf.wyvern.base.events.impl.other.EventTick;
import wtf.wyvern.client.modules.api.Category;
import wtf.wyvern.client.modules.api.Module;
import wtf.wyvern.client.modules.api.ModuleAnnotation;
import wtf.wyvern.client.modules.api.setting.impl.BooleanSetting;
import wtf.wyvern.client.modules.api.setting.impl.NumberSetting;
import wtf.wyvern.utility.game.player.PlayerInventoryUtil;
import wtf.wyvern.utility.game.server.AutoBuyUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@ModuleAnnotation(
        name = "ChestStealer",
        category = Category.PLAYER,
        description = "Автоматически забирает предметы из открытых контейнеров"
)
public final class ChestStealer extends Module {
    public static final ChestStealer INSTANCE = new ChestStealer();

    /** Number of slots that belong to the player inventory (27 main + 9 hotbar). */
    private static final int PLAYER_SLOTS = 36;

    private final NumberSetting delay = new NumberSetting("Задержка (мс)", 80.0f, 0.0f, 500.0f, 10.0f);
    private final NumberSetting closeDelay = new NumberSetting("Задержка закрытия (мс)", 150.0f, 0.0f, 1000.0f, 50.0f);
    private final BooleanSetting randomOrder = new BooleanSetting("Случайный порядок", false);
    private final BooleanSetting autoClose = new BooleanSetting("Автозакрытие", true);
    private final BooleanSetting stopWhenFull = new BooleanSetting("Стоп при полном инвентаре", true);
    private final BooleanSetting skipAuction = new BooleanSetting("Не трогать аукцион", true);

    private int lastSyncId = -1;
    private long nextActionAt;
    private long idleSince;

    private ChestStealer() {
    }

    @Override
    public void onEnable() {
        resetState();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        resetState();
        super.onDisable();
    }

    private void resetState() {
        lastSyncId = -1;
        nextActionAt = 0L;
        idleSince = 0L;
    }

    @EventTarget
    private void onTick(EventTick e) {
        if (mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }

        class_437 screen = mc.field_1755;
        if (!(screen instanceof class_476)) {
            resetState();
            return;
        }

        class_1703 handler = mc.field_1724.field_7512;
        if (handler == null || handler != ((class_476) screen).method_17577()) {
            return;
        }

        if (skipAuction.isEnabled() && AutoBuyUtil.isAuction(handler)) {
            return;
        }

        int total = handler.field_7761.size();
        int containerSize = total - PLAYER_SLOTS;
        if (containerSize <= 0) {
            return;
        }

        long now = System.currentTimeMillis();

        // fresh container: wait one delay so the server contents sync first
        if (handler.field_7763 != lastSyncId) {
            lastSyncId = handler.field_7763;
            nextActionAt = now + (long) delay.getCurrent();
            idleSince = 0L;
            return;
        }

        if (now < nextActionAt) {
            return;
        }

        boolean full = stopWhenFull.isEnabled() && isInventoryFull(handler, containerSize, total);

        List<Integer> candidates = new ArrayList<>();
        if (!full) {
            for (int i = 0; i < containerSize; i++) {
                class_1735 slot = handler.field_7761.get(i);
                if (!slot.method_7677().method_7960()) {
                    candidates.add(i);
                }
            }
        }

        if (candidates.isEmpty()) {
            if (autoClose.isEnabled()) {
                if (idleSince == 0L) {
                    idleSince = now;
                }
                if (now - idleSince >= (long) closeDelay.getCurrent()) {
                    screen.method_25419();
                    resetState();
                }
            }
            return;
        }

        idleSince = 0L;
        int index = randomOrder.isEnabled()
                ? candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()))
                : candidates.get(0);

        PlayerInventoryUtil.clickSlot(index, 0, class_1713.field_7794, false);

        long wait = (long) delay.getCurrent();
        if (randomOrder.isEnabled() && wait > 0L) {
            wait += ThreadLocalRandom.current().nextLong(0L, wait / 3L + 1L);
        }
        nextActionAt = now + wait;
    }

    private static boolean isInventoryFull(class_1703 handler, int from, int to) {
        for (int i = from; i < to; i++) {
            if (handler.field_7761.get(i).method_7677().method_7960()) {
                return false;
            }
        }
        return true;
    }
}
