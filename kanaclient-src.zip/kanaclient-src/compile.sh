#!/bin/bash
cd "$(dirname "$0")"
unset JAVA_TOOL_OPTIONS
rm -rf out && mkdir -p out
javac --release 21 -encoding UTF-8 -proc:none -nowarn -cp "../kana/x" -d out $(find stubs src -name '*.java') 2>&1 | grep -v "^Note:" | head -60
