package wtf.wyvern.client.modules.impl.render;

import wtf.wyvern.client.modules.api.Category;
import wtf.wyvern.client.modules.api.Module;
import wtf.wyvern.client.modules.api.ModuleAnnotation;
import wtf.wyvern.client.modules.api.setting.impl.BooleanSetting;
import wtf.wyvern.client.modules.api.setting.impl.NumberSetting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Performance mode. While enabled it switches off the heaviest visual modules of the client
 * (and restores exactly those it switched off when disabled) and tightens world scans.
 */
@ModuleAnnotation(
        name = "Optimization",
        category = Category.RENDER,
        description = "Повышает FPS: отключает тяжёлые эффекты и ограничивает сканирование мира"
)
public final class Optimization extends Module {
    public static final Optimization INSTANCE = new Optimization();

    /** Vertical scan range used by world scanners while the module is off. */
    private static final int DEFAULT_SCAN_RANGE = 64;

    private final BooleanSetting particles = new BooleanSetting("Частицы клиента", true);
    private final BooleanSetting shaderHands = new BooleanSetting("Шейдер рук", true);
    private final BooleanSetting bloomBlock = new BooleanSetting("Свечение блоков", true);
    private final BooleanSetting cubes = new BooleanSetting("Кубы", true);
    private final BooleanSetting lineGlyphes = new BooleanSetting("Линии-глифы", true);
    private final BooleanSetting killEffect = new BooleanSetting("Эффекты убийств", true);
    private final BooleanSetting customSky = new BooleanSetting("Кастомное небо", false);
    private final BooleanSetting jumpCircle = new BooleanSetting("Круги прыжка", false);
    private final NumberSetting scanRange = new NumberSetting("Высота сканирования", 32.0f, 8.0f, 128.0f, 8.0f);

    private final List<Module> switchedOff = new ArrayList<>();

    private Optimization() {
    }

    @Override
    public void onEnable() {
        switchedOff.clear();
        turnOff(particles, () -> Particles.INSTANCE);
        turnOff(shaderHands, () -> ShaderHands.INSTANCE);
        turnOff(bloomBlock, () -> BloomBlock.INSTANCE);
        turnOff(cubes, () -> Cubes.INSTANCE);
        turnOff(lineGlyphes, () -> LineGlyphes.INSTANCE);
        turnOff(killEffect, () -> KillEffect.INSTANCE);
        turnOff(customSky, () -> CustomSky.INSTANCE);
        turnOff(jumpCircle, () -> JumpCircle.INSTANCE);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        for (Module m : switchedOff) {
            if (!m.isEnabled()) {
                m.setToggled(true);
            }
        }
        switchedOff.clear();
        super.onDisable();
    }

    private void turnOff(BooleanSetting setting, Supplier<? extends Module> target) {
        if (!setting.isEnabled()) {
            return;
        }
        Module m = target.get();
        if (m != null && m != this && m.isEnabled()) {
            m.setToggled(false);
            switchedOff.add(m);
        }
    }

    // ------------------------------------------------------------------ hooks used by patched scanners

    private static int range() {
        return INSTANCE.isEnabled() ? Math.round(INSTANCE.scanRange.getCurrent()) : DEFAULT_SCAN_RANGE;
    }

    /** Lower Y bound of a world scan, limited to a band around the player. */
    public static int clampMinY(int minY) {
        if (mc.field_1724 == null) {
            return minY;
        }
        return Math.max(minY, mc.field_1724.method_24515().method_10264() - range());
    }

    /** Upper Y bound of a world scan, limited to a band around the player. */
    public static int clampMaxY(int maxY) {
        if (mc.field_1724 == null) {
            return maxY;
        }
        return Math.min(maxY, mc.field_1724.method_24515().method_10264() + range());
    }
}
