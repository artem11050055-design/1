package wtf.wyvern.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2304;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2363;
import net.minecraft.class_2480;
import net.minecraft.class_3708;
import net.minecraft.class_638;
import wtf.wyvern.base.events.impl.other.EventTick;
import wtf.wyvern.base.events.impl.render.EventRender3D;
import wtf.wyvern.client.modules.api.Category;
import wtf.wyvern.client.modules.api.Module;
import wtf.wyvern.client.modules.api.ModuleAnnotation;
import wtf.wyvern.client.modules.api.setting.impl.BooleanSetting;
import wtf.wyvern.client.modules.api.setting.impl.ColorSetting;
import wtf.wyvern.client.modules.api.setting.impl.NumberSetting;
import wtf.wyvern.utility.render.display.base.color.ColorRGBA;
import wtf.wyvern.utility.render.level.Render3DUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@ModuleAnnotation(
        name = "StorageESP",
        category = Category.RENDER,
        description = "Подсвечивает хранилища: сундуки, бочки, шалкеры"
)
public final class StorageESP extends Module {
    public static final StorageESP INSTANCE = new StorageESP();

    private static final int TYPE_CHEST = 0;
    private static final int TYPE_BARREL = 1;
    private static final int TYPE_SHULKER = 2;
    private static final int TYPE_OTHER = 3;

    private final NumberSetting radius = new NumberSetting("Радиус (чанки)", 3.0f, 1.0f, 8.0f, 1.0f);
    private final NumberSetting height = new NumberSetting("Высота (блоки)", 32.0f, 8.0f, 128.0f, 8.0f);
    private final NumberSetting lineWidth = new NumberSetting("Толщина", 1.5f, 0.5f, 4.0f, 0.5f);

    private final BooleanSetting chests = new BooleanSetting("Сундуки", true);
    private final BooleanSetting barrels = new BooleanSetting("Бочки", true);
    private final BooleanSetting shulkers = new BooleanSetting("Шалкеры", true);
    private final BooleanSetting others = new BooleanSetting("Прочие", true);

    private final ColorSetting chestColor = new ColorSetting("Цвет сундуков", new ColorRGBA(255, 170, 0, 200));
    private final ColorSetting barrelColor = new ColorSetting("Цвет бочек", new ColorRGBA(160, 110, 60, 200));
    private final ColorSetting shulkerColor = new ColorSetting("Цвет шалкеров", new ColorRGBA(200, 90, 255, 200));
    private final ColorSetting otherColor = new ColorSetting("Цвет прочих", new ColorRGBA(90, 200, 255, 200));

    /** Chunks scanned per client tick. Keeps the main thread load flat. */
    private static final int CHUNKS_PER_TICK = 2;

    private final Map<Long, List<Spot>> cache = new HashMap<>();
    private final List<long[]> queue = new ArrayList<>();
    private int queueIndex;
    private int lastChunkX = Integer.MIN_VALUE;
    private int lastChunkZ = Integer.MIN_VALUE;
    private int lastRadius = -1;

    private StorageESP() {
    }

    @Override
    public void onEnable() {
        reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        reset();
        super.onDisable();
    }

    private void reset() {
        cache.clear();
        queue.clear();
        queueIndex = 0;
        lastChunkX = Integer.MIN_VALUE;
        lastChunkZ = Integer.MIN_VALUE;
        lastRadius = -1;
    }

    @EventTarget
    private void onTick(EventTick e) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            if (!cache.isEmpty()) {
                reset();
            }
            return;
        }

        int r = Math.round(radius.getCurrent());
        class_2338 p = mc.field_1724.method_24515();
        int pcx = p.method_10263() >> 4;
        int pcz = p.method_10260() >> 4;

        if (pcx != lastChunkX || pcz != lastChunkZ || r != lastRadius) {
            lastChunkX = pcx;
            lastChunkZ = pcz;
            lastRadius = r;
            rebuildQueue(pcx, pcz, r);
        }

        if (queue.isEmpty()) {
            return;
        }

        for (int i = 0; i < CHUNKS_PER_TICK; i++) {
            if (queueIndex >= queue.size()) {
                queueIndex = 0;
            }
            long[] c = queue.get(queueIndex++);
            scanChunk((int) c[0], (int) c[1], p.method_10264());
        }
    }

    private void rebuildQueue(int pcx, int pcz, int r) {
        queue.clear();
        Set<Long> keep = new HashSet<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                queue.add(new long[]{pcx + dx, pcz + dz});
                keep.add(key(pcx + dx, pcz + dz));
            }
        }
        // closest chunks first
        queue.sort((a, b) -> Long.compare(
                (a[0] - pcx) * (a[0] - pcx) + (a[1] - pcz) * (a[1] - pcz),
                (b[0] - pcx) * (b[0] - pcx) + (b[1] - pcz) * (b[1] - pcz)));
        cache.keySet().retainAll(keep);
        queueIndex = 0;
    }

    private void scanChunk(int cx, int cz, int playerY) {
        class_638 world = mc.field_1687;
        long k = key(cx, cz);
        if (!world.method_8393(cx, cz)) {
            cache.remove(k);
            return;
        }

        int vr = Math.round(height.getCurrent());
        int minY = Math.max(world.method_31607(), playerY - vr);
        int maxY = Math.min(world.method_31605(), playerY + vr);
        int bx = cx << 4;
        int bz = cz << 4;

        List<Spot> found = new ArrayList<>();
        for (int x = bx; x < bx + 16; x++) {
            for (int z = bz; z < bz + 16; z++) {
                for (int y = minY; y < maxY; y++) {
                    class_2338 pos = new class_2338(x, y, z);
                    int type = typeOf(world.method_8320(pos).method_26204());
                    if (type >= 0) {
                        found.add(new Spot(pos, type));
                    }
                }
            }
        }
        cache.put(k, found);
    }

    private static int typeOf(class_2248 block) {
        if (block instanceof class_2281) return TYPE_CHEST;
        if (block instanceof class_3708) return TYPE_BARREL;
        if (block instanceof class_2480) return TYPE_SHULKER;
        if (block instanceof class_2304 || block instanceof class_2363) return TYPE_OTHER;
        return -1;
    }

    @EventTarget
    private void onRender3D(EventRender3D e) {
        if (mc.field_1724 == null || mc.field_1687 == null || cache.isEmpty()) {
            return;
        }

        float width = lineWidth.getCurrent();
        for (List<Spot> spots : cache.values()) {
            for (Spot s : spots) {
                if (!isTypeEnabled(s.type)) {
                    continue;
                }
                // drop stale entries (block broken since the last scan)
                if (typeOf(mc.field_1687.method_8320(s.pos).method_26204()) != s.type) {
                    continue;
                }
                Render3DUtil.drawBox(s.box, colorOf(s.type), width);
            }
        }
    }

    private boolean isTypeEnabled(int type) {
        switch (type) {
            case TYPE_CHEST: return chests.isEnabled();
            case TYPE_BARREL: return barrels.isEnabled();
            case TYPE_SHULKER: return shulkers.isEnabled();
            default: return others.isEnabled();
        }
    }

    private int colorOf(int type) {
        switch (type) {
            case TYPE_CHEST: return chestColor.getIntColor();
            case TYPE_BARREL: return barrelColor.getIntColor();
            case TYPE_SHULKER: return shulkerColor.getIntColor();
            default: return otherColor.getIntColor();
        }
    }

    private static long key(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xFFFFFFFFL);
    }

    private static final class Spot {
        final class_2338 pos;
        final class_238 box;
        final int type;

        Spot(class_2338 pos, int type) {
            this.pos = pos;
            this.type = type;
            this.box = new class_238(pos);
        }
    }
}
