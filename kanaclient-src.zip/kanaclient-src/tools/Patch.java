import org.objectweb.asm.*;
import java.nio.file.*;
import java.util.*;

/** Appends registerModule(X.INSTANCE) calls before RETURN of given private register* methods. */
public class Patch {
    public static void main(String[] a) throws Exception {
        Path in = Paths.get(a[0]), out = Paths.get(a[1]);
        Map<String, String[]> add = new LinkedHashMap<>();
        add.put("registerRender", new String[]{"wtf/wyvern/client/modules/impl/render/StorageESP", "wtf/wyvern/client/modules/impl/render/Optimization"});
        add.put("registerPlayer", new String[]{"wtf/wyvern/client/modules/impl/player/ChestStealer"});
        add.put("registerMisc", new String[]{"wtf/wyvern/client/modules/impl/misc/AHHelper"});
        String self = "wtf/wyvern/base/modules/ModuleManager";
        String modDesc = "Lwtf/wyvern/client/modules/api/Module;";
        Set<String> done = new HashSet<>();

        ClassReader cr = new ClassReader(Files.readAllBytes(in));
        ClassWriter cw = new ClassWriter(cr, 0);
        cr.accept(new ClassVisitor(Opcodes.ASM9, cw) {
            public MethodVisitor visitMethod(int acc, String name, String desc, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(acc, name, desc, sig, ex);
                String[] target = add.get(name);
                if (target == null || !desc.equals("()V")) return mv;
                return new MethodVisitor(Opcodes.ASM9, mv) {
                    public void visitInsn(int op) {
                        if (op == Opcodes.RETURN) {
                            for (String t : target) {
                                super.visitVarInsn(Opcodes.ALOAD, 0);
                                super.visitFieldInsn(Opcodes.GETSTATIC, t, "INSTANCE", "L" + t + ";");
                                super.visitMethodInsn(Opcodes.INVOKEVIRTUAL, self, "registerModule", "(" + modDesc + ")V", false);
                            }
                            done.add(name);
                        }
                        super.visitInsn(op);
                    }
                    public void visitMaxs(int s, int l) { super.visitMaxs(Math.max(s, 2), l); }
                };
            }
        }, 0);
        if (done.size() != add.size()) throw new IllegalStateException("not all patched: " + done);
        Files.write(out, cw.toByteArray());
        System.out.println("patched " + done);
    }
}
