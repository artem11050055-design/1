package wtf.wyvern.utility.mixin.client;

import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wtf.wyvern.client.screens.MenuStyle;

/** Replaces the panorama of the main menu with the client's animated background. */
@Mixin(class_437.class)
public abstract class TitleBackgroundMixin {
    @Inject(method = "method_25420", at = @At("HEAD"), cancellable = true, require = 0)
    private void wyvern$titleBackground(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (((Object) this) instanceof class_442 && MenuStyle.drawBackground(context)) {
            ci.cancel();
        }
    }
}
