package wtf.wyvern.utility.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wtf.wyvern.client.screens.MenuStyle;

/** Draws the main menu buttons as pills instead of vanilla rectangles. */
@Mixin(class_339.class)
public abstract class RoundButtonMixin {
    @Inject(method = "method_25394", at = @At("HEAD"), cancellable = true, require = 0)
    private void wyvern$roundButton(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!(((Object) this) instanceof class_4185)) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null || !(mc.field_1755 instanceof class_442)) {
            return;
        }
        if (MenuStyle.drawButton((class_339) (Object) this, context, mouseX, mouseY)) {
            ci.cancel();
        }
    }
}
