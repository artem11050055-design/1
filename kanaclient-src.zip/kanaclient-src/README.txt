Исходники изменений для kanaclient.jar

src/   - код (Java 21), пакеты wtf.wyvern.*
  client/modules/impl/render/StorageESP.java    - подсветка хранилищ
  client/modules/impl/player/ChestStealer.java  - автолут контейнеров
  client/modules/impl/render/Optimization.java  - режим оптимизации
  client/screens/MenuStyle.java                 - фон и круглые кнопки главного меню
  utility/mixin/client/TitleBackgroundMixin.java, RoundButtonMixin.java
stubs/ - заглушки классов Minecraft (intermediary) и Mixin, только для компиляции; в jar НЕ попадают
tools/ - ASM-патчеры:
  Patch.java   - регистрирует StorageESP, Optimization, ChestStealer, AHHelper в ModuleManager
  PatchBF.java - ограничивает вертикальную зону сканирования BaseFinder
  RefDump.java - проверка, что все вызовы Minecraft есть в оригинальном клиенте
compile.sh - компиляция против распакованного оригинального jar (путь ../kana/x внутри скрипта)

AHHelper в клиенте уже был, добавлена только регистрация.
Миксины нужно добавить в wyvern.mixins.json (список "client"): client.TitleBackgroundMixin, client.RoundButtonMixin.
AutoWarden и новые визуалы (Trail, подсветка блока) в эту версию НЕ вошли: не доделаны.
