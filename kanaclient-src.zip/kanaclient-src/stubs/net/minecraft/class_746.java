package net.minecraft;
public class class_746 { public class_1703 field_7512; public class_2338 method_24515(){return null;} }
