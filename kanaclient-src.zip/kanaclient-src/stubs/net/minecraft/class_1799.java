package net.minecraft;
public class class_1799 { public boolean method_7960(){return false;} }
