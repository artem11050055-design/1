package net.minecraft;
public class class_1703 { public class_2371<class_1735> field_7761; public int field_7763; }
