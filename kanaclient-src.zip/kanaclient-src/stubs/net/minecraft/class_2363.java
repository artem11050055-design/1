package net.minecraft;
public class class_2363 extends class_2248 { }
