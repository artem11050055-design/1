package wtf.wyvern.client.screens;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4587;
import wtf.wyvern.utility.render.display.base.BorderRadius;
import wtf.wyvern.utility.render.display.base.Gradient;
import wtf.wyvern.utility.render.display.base.color.ColorRGBA;
import wtf.wyvern.utility.render.display.shader.DrawUtil;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Visual style of the main menu: animated background and pill-shaped buttons.
 * All drawing is guarded: any failure disables the custom style and vanilla rendering takes over.
 */
public final class MenuStyle {
    private static final long START = System.nanoTime();
    private static boolean backgroundBroken;
    private static boolean buttonsBroken;

    private static final Map<Object, float[]> HOVER = new WeakHashMap<>();

    private MenuStyle() {
    }

    // ------------------------------------------------------------------ background

    /** @return true if the background was drawn and vanilla should be skipped. */
    public static boolean drawBackground(class_332 ctx) {
        if (backgroundBroken) {
            return false;
        }
        try {
            class_4587 ms = ctx.method_51448();
            float w = ctx.method_51421();
            float h = ctx.method_51443();
            double t = (System.nanoTime() - START) / 1.0e9;

            // slowly breathing deep-space gradient
            float k = (float) (0.5 + 0.5 * Math.sin(t * 0.15));
            ColorRGBA tl = mix(new ColorRGBA(8, 10, 28, 255), new ColorRGBA(14, 8, 36, 255), k);
            ColorRGBA bl = mix(new ColorRGBA(30, 14, 62, 255), new ColorRGBA(18, 22, 70, 255), k);
            ColorRGBA br = mix(new ColorRGBA(52, 16, 74, 255), new ColorRGBA(24, 34, 88, 255), k);
            ColorRGBA tr = mix(new ColorRGBA(10, 28, 58, 255), new ColorRGBA(26, 14, 60, 255), k);
            DrawUtil.drawRoundedRect(ms, 0f, 0f, w, h, BorderRadius.ZERO, Gradient.of(tl, bl, br, tr));

            // drifting soft glows
            int[][] orbs = {
                    {120, 70, 255}, {255, 70, 170}, {60, 170, 255}, {150, 90, 255}, {70, 220, 200}
            };
            float base = Math.min(w, h);
            for (int i = 0; i < orbs.length; i++) {
                double px = 0.5 + 0.42 * Math.sin(t * (0.10 + 0.02 * i) + i * 1.9);
                double py = 0.5 + 0.38 * Math.cos(t * (0.08 + 0.015 * i) + i * 2.4);
                float r = base * (0.30f + 0.06f * (i % 3));
                glow(ms, (float) (w * px), (float) (h * py), r, orbs[i][0], orbs[i][1], orbs[i][2], 7);
            }

            // twinkling stars
            long seed = 0x9E3779B97F4A7C15L;
            for (int i = 0; i < 70; i++) {
                seed = seed * 6364136223846793005L + 1442695040888963407L;
                float sx = ((seed >>> 33) % 1000) / 1000f;
                seed = seed * 6364136223846793005L + 1442695040888963407L;
                float sy = ((seed >>> 33) % 1000) / 1000f;
                float drift = (float) ((t * (2 + (i % 5))) % w);
                float x = (sx * w + drift) % w;
                float y = sy * h;
                float tw = (float) (0.5 + 0.5 * Math.sin(t * 1.5 + i * 0.7));
                float size = (i % 9 == 0) ? 2.4f : 1.4f;
                DrawUtil.drawRoundedRect(ms, x, y, size, size, BorderRadius.all(size / 2f),
                        new ColorRGBA(255, 255, 255, (int) (40 + 150 * tw)));
            }

            // subtle darkening towards the edges for depth
            DrawUtil.drawRoundedRect(ms, 0f, h * 0.72f, w, h * 0.28f, BorderRadius.ZERO,
                    Gradient.of(new ColorRGBA(0, 0, 0, 0), new ColorRGBA(0, 0, 0, 120),
                            new ColorRGBA(0, 0, 0, 120), new ColorRGBA(0, 0, 0, 0)));
            return true;
        } catch (Throwable ex) {
            backgroundBroken = true;
            return false;
        }
    }

    private static void glow(class_4587 ms, float cx, float cy, float radius, int r, int g, int b, int alpha) {
        int steps = 10;
        for (int i = 0; i < steps; i++) {
            float f = 1f - (float) i / steps;
            float rr = radius * f;
            DrawUtil.drawRoundedRect(ms, cx - rr, cy - rr, rr * 2, rr * 2, BorderRadius.all(rr),
                    new ColorRGBA(r, g, b, alpha));
        }
    }

    // ------------------------------------------------------------------ buttons

    /** @return true if the button was drawn as a pill and vanilla rendering must be skipped. */
    public static boolean drawButton(class_339 widget, class_332 ctx, int mouseX, int mouseY) {
        if (buttonsBroken) {
            return false;
        }
        try {
            int x = widget.method_46426();
            int y = widget.method_46427();
            int w = widget.method_25368();
            int h = widget.method_25364();
            if (w < 40 || h < 12) {
                return false; // icon buttons stay vanilla
            }
            String text = widget.method_25369().getString();
            if (text == null || text.isEmpty()) {
                return false;
            }

            boolean visible = true;
            boolean active = true;
            try {
                visible = widget.field_22764;
                active = widget.field_22763;
            } catch (Throwable ignored) {
            }
            if (!visible) {
                return true;
            }

            boolean hovered = active && mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;

            float[] anim = HOVER.computeIfAbsent(widget, o -> new float[]{0f});
            anim[0] += ((hovered ? 1f : 0f) - anim[0]) * 0.25f;

            class_4587 ms = ctx.method_51448();
            float radius = h / 2f;
            float p = anim[0];

            // soft outer halo while hovered
            if (p > 0.01f) {
                DrawUtil.drawRoundedRect(ms, x - 2f, y - 2f, w + 4f, h + 4f, BorderRadius.all(radius + 2f),
                        new ColorRGBA(150, 110, 255, (int) (70 * p)));
            }
            // thin light rim
            DrawUtil.drawRoundedRect(ms, x - 1f, y - 1f, w + 2f, h + 2f, BorderRadius.all(radius + 1f),
                    new ColorRGBA(255, 255, 255, active ? (int) (38 + 60 * p) : 18));
            // body
            ColorRGBA left = mix(new ColorRGBA(26, 22, 52, 225), new ColorRGBA(96, 64, 200, 235), p);
            ColorRGBA right = mix(new ColorRGBA(36, 26, 70, 225), new ColorRGBA(150, 70, 210, 235), p);
            if (!active) {
                left = new ColorRGBA(24, 24, 32, 200);
                right = new ColorRGBA(30, 30, 40, 200);
            }
            DrawUtil.drawRoundedRect(ms, x, y, w, h, BorderRadius.all(radius),
                    Gradient.of(left, left, right, right));

            int color = active ? 0xFFFFFFFF : 0xFF8A8A98;
            class_310 mc = class_310.method_1551();
            ctx.method_25300(mc.field_1772, text, x + w / 2, y + (h - 8) / 2, color);
            return true;
        } catch (Throwable ex) {
            buttonsBroken = true;
            return false;
        }
    }

    private static ColorRGBA mix(ColorRGBA a, ColorRGBA b, float t) {
        return new ColorRGBA(
                Math.round(a.getRed() + (b.getRed() - a.getRed()) * t),
                Math.round(a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                Math.round(a.getBlue() + (b.getBlue() - a.getBlue()) * t),
                Math.round(a.getAlpha() + (b.getAlpha() - a.getAlpha()) * t));
    }
}
