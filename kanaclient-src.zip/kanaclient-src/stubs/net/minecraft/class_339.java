package net.minecraft;
public abstract class class_339 { public boolean field_22763; public boolean field_22764; public int method_46426(){return 0;} public int method_46427(){return 0;} public int method_25368(){return 0;} public int method_25364(){return 0;} public class_2561 method_25369(){return null;} }
