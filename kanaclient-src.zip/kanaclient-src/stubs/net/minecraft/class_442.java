package net.minecraft;
public class class_442 extends class_437 { }
