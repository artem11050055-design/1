import org.objectweb.asm.*;
import java.nio.file.*;

/** BaseFinder.scanChunkBlocks: clamp the Y range (locals 5 = min, 6 = max) through Optimization hooks. */
public class PatchBF {
    public static void main(String[] a) throws Exception {
        String opt = "wtf/wyvern/client/modules/impl/render/Optimization";
        int[] hits = new int[2];
        ClassReader cr = new ClassReader(Files.readAllBytes(Paths.get(a[0])));
        ClassWriter cw = new ClassWriter(cr, 0);
        cr.accept(new ClassVisitor(Opcodes.ASM9, cw) {
            public MethodVisitor visitMethod(int acc, String n, String d, String s, String[] e) {
                MethodVisitor mv = super.visitMethod(acc, n, d, s, e);
                if (!n.equals("scanChunkBlocks")) return mv;
                return new MethodVisitor(Opcodes.ASM9, mv) {
                    public void visitVarInsn(int op, int v) {
                        if (op == Opcodes.ISTORE && v == 5 && hits[0] == 0) {
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, opt, "clampMinY", "(I)I", false); hits[0]++;
                        } else if (op == Opcodes.ISTORE && v == 6 && hits[1] == 0) {
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, opt, "clampMaxY", "(I)I", false); hits[1]++;
                        }
                        super.visitVarInsn(op, v);
                    }
                    public void visitMaxs(int s, int l) { super.visitMaxs(Math.max(s, 3), l); }
                };
            }
        }, 0);
        if (hits[0] != 1 || hits[1] != 1) throw new IllegalStateException("hits " + hits[0] + "," + hits[1]);
        Files.write(Paths.get(a[1]), cw.toByteArray());
        System.out.println("BaseFinder patched");
    }
}
