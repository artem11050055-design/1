import org.objectweb.asm.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

/** Dump all net/minecraft member refs (owner.name:desc) used by classes under a directory. */
public class RefDump {
    public static void main(String[] a) throws Exception {
        Set<String> refs = new TreeSet<>();
        try (Stream<Path> s = Files.walk(Paths.get(a[0]))) {
            for (Path p : (Iterable<Path>) s.filter(x -> x.toString().endsWith(".class"))::iterator) {
                String ps = p.toString();
                if (ps.contains("/assets/") || ps.contains("/META-INF/") || ps.contains("/viaversion/")) continue;
                ClassReader cr = new ClassReader(Files.readAllBytes(p));
                cr.accept(new ClassVisitor(Opcodes.ASM9) {
                    public MethodVisitor visitMethod(int acc, String n, String d, String sg, String[] ex) {
                        return new MethodVisitor(Opcodes.ASM9) {
                            public void visitFieldInsn(int op, String o, String nm, String ds) {
                                if (o.startsWith("net/minecraft/")) refs.add("F " + o + "." + nm + ":" + ds);
                            }
                            public void visitMethodInsn(int op, String o, String nm, String ds, boolean itf) {
                                if (o.startsWith("net/minecraft/")) refs.add("M " + o + "." + nm + ds);
                            }
                            public void visitTypeInsn(int op, String t) {
                                if (t.startsWith("net/minecraft/")) refs.add("C " + t);
                            }
                        };
                    }
                }, 0);
            }
        }
        Files.write(Paths.get(a[1]), refs);
        System.out.println(refs.size() + " refs");
    }
}
